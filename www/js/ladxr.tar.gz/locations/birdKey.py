from .droppedKey import DroppedKey


class BirdKey(DroppedKey):
    def __init__(self):
        super().__init__(0x27A)

